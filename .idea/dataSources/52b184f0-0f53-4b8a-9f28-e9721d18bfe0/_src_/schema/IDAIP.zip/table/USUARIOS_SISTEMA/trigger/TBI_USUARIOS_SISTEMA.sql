CREATE TRIGGER TBI_USUARIOS_SISTEMA
BEFORE INSERT
  ON USUARIOS_SISTEMA
FOR EACH ROW
  declare
  tmpSeq Number(9) := 0;
begin
  If :New.Usuario_Sistema_Id Is Null Then
    Select Seq_Usuario_sistema_id.Nextval Into tmpseq From Dual;
    :New.Usuario_Sistema_Id  := tmpseq;
  End If;

end TBI_Usuarios_Sistema;
/
