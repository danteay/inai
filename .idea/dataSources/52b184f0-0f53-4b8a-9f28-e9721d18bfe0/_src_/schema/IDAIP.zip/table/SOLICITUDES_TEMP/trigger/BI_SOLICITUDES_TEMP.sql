CREATE TRIGGER BI_SOLICITUDES_TEMP
BEFORE INSERT
  ON SOLICITUDES_TEMP
FOR EACH ROW
  begin   
  if :NEW."SOLICITUD_TEMP_ID" is null then 
    select "SOL_TEMP_SEQ".nextval into :NEW."SOLICITUD_TEMP_ID" from sys.dual; 
  end if; 
end;
/
