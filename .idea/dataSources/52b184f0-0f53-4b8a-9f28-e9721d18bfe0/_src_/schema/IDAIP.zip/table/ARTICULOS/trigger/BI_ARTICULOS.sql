CREATE TRIGGER BI_ARTICULOS
BEFORE INSERT
  ON ARTICULOS
FOR EACH ROW
  begin   
  if :NEW."ARTICULO_ID" is null then 
    select "ARTICULOS_SEQ".nextval into :NEW."ARTICULO_ID" from sys.dual; 
  end if; 
  :New.Activo  := 1;
  :New.Estatus := 1;
end;
/
