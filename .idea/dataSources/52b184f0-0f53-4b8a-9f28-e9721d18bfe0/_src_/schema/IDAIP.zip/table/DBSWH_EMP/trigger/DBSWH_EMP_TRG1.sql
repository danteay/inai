CREATE TRIGGER DBSWH_EMP_TRG1
BEFORE INSERT
  ON DBSWH_EMP
FOR EACH ROW
  begin
    if :new.empno is null then
        select DBSWH_EMP_SEQ.nextval into :new.empno from dual;
   end if;
end;
/
