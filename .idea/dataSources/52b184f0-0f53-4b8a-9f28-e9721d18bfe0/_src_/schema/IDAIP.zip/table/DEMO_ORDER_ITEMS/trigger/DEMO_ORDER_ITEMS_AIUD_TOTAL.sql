CREATE TRIGGER DEMO_ORDER_ITEMS_AIUD_TOTAL
AFTER INSERT OR UPDATE OR DELETE
  ON DEMO_ORDER_ITEMS
  begin
  -- Update the Order Total when any order item is changed
  update demo_orders set order_total =
  (select sum(unit_price*quantity) from demo_order_items
    where demo_order_items.order_id = demo_orders.order_id);
end;
/
