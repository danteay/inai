CREATE TRIGGER BD_ART_FRACC_RESPUESTAS
BEFORE DELETE
  ON ART_FRACC_RESPUESTAS
FOR EACH ROW
  begin
  Insert Into DET_EVAL_FRACCIONES_temp
   select * from DET_EVAL_FRACCIONES
     Where Art_Fracc_Respuesta_Id = :Old.Art_Fracc_Respuesta_Id;

  Delete DET_EVAL_FRACCIONES
    Where Art_Fracc_Respuesta_Id = :Old.Art_Fracc_Respuesta_Id;

end;
/
