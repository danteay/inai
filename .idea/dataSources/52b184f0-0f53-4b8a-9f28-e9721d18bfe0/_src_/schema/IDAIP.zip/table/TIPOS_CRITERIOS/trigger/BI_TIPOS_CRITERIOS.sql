CREATE TRIGGER BI_TIPOS_CRITERIOS
BEFORE INSERT
  ON TIPOS_CRITERIOS
FOR EACH ROW
  begin   
  if :NEW."TIPO_CRITERIO_ID" is null then 
    select "TIPOS_CRITERIOS_SEQ".nextval into :NEW."TIPO_CRITERIO_ID" from sys.dual; 
  end if; 
end;
/
