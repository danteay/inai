CREATE TRIGGER TBU_SUJETOS_ARTICULOS
BEFORE UPDATE
  ON SUJETOS_ARTICULOS
FOR EACH ROW
  begin
  If Updating('Estatus') Then
    If :New.Estatus = 1 Then
      Pgk_Idaip.Pro_Act_Sujetos_Fracciones(:New.Sujeto_Obligado_Id ,
                                           :New.Articulo_Id);
    End If;
  End If;
end;
/
