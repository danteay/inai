CREATE TRIGGER BI_SUJETOS_ARTICULOS
BEFORE INSERT
  ON SUJETOS_ARTICULOS
FOR EACH ROW
  begin   
  if :NEW."SUJETO_ARTICULO_ID" is null then 
    select "SUJETOS_ARTICULOS_SEQ".nextval into :NEW."SUJETO_ARTICULO_ID" from sys.dual; 
  end if; 
  
  If :New.Estatus = 1 Then
    pgk_idaip.pro_act_sujetos_fracciones(:New.Sujeto_Obligado_Id ,
                                         :New.Articulo_Id);  
  End If;  
end;
/
