CREATE TRIGGER TBI_ROLES_USUARIO
BEFORE INSERT
  ON ROLES_USUARIO
FOR EACH ROW
  declare
  tmpSeq Number(9) := 0;
begin
  If :New.Rol_Usuario_Id Is Null Then
    Select Seq_Roles_Usuario_id.Nextval Into tmpseq From Dual;
    :New.Rol_Usuario_Id  := tmpseq;
  End If;

end TBI_Roles_Usuario;
/
