CREATE TRIGGER BD_ARTICULOS_FRACCIONES
BEFORE DELETE
  ON ARTICULOS_FRACCIONES
FOR EACH ROW
  begin
  Delete det_eval_fracciones
    Where art_fracc_respuesta_id In (
    Select art_fracc_respuesta_id  from ART_FRACC_RESPUESTAS
       Where articulo_fraccion_id = :Old.articulo_fraccion_id
       );

  Delete EVALUACIONES_FRACCIONES
    Where articulo_fraccion_id = :Old.articulo_fraccion_id;        
  
   
   Delete ART_FRACC_RESPUESTAS
     Where ARTICULO_FRACCION_ID = :Old.articulo_fraccion_id;    

end;
/
