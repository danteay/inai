CREATE TRIGGER TAI_EVALUACIONES
AFTER INSERT
  ON EVALUACIONES
FOR EACH ROW
  begin

  If :New.sujeto_obligado_id Is Not Null Then
     Null;
   -- pgk_idaip.pro_crear_encuesta_2017(:NEW.EVALUACION_ID,
   --                                   :New.Sujeto_Obligado_Id,
   --                                   :New.Usuario_Evalua);
  End If;
end;
/
