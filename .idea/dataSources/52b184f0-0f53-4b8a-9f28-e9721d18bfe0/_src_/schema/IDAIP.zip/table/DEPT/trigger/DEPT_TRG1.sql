CREATE TRIGGER DEPT_TRG1
BEFORE INSERT
  ON DEPT
FOR EACH ROW
  begin
                  if :new.deptno is null then
                      select dept_seq.nextval into :new.deptno from sys.dual;
                 end if;
              end;
/
