CREATE TRIGGER BI_RESUMEN_EVA
BEFORE INSERT
  ON RESUMEN_EVA
FOR EACH ROW
  begin   
  if :NEW."RESUMEN_EVA_ID" is null then 
    select "RESUMEN_EVA_SEQ".nextval into :NEW."RESUMEN_EVA_ID" from sys.dual; 
  end if; 
end;
/
