CREATE TRIGGER BI_VERI_2014_V
BEFORE INSERT
  ON VERI_2014_V
FOR EACH ROW
  begin   
  if :NEW."VERI_2014_ID" is null then 
    select "VERI_2014_V_SEQ".nextval into :NEW."VERI_2014_ID" from sys.dual; 
  end if; 
end;
/
