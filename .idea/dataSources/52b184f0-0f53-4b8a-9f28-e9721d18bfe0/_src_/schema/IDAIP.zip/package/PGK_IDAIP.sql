CREATE package pgk_idaip is
   Procedure pro_Act_Sujetos_Fracciones(pSujeto_Id   Number,
                                        pArticulo_Id Number);
  Procedure pro_Act_Sujetos_Articulos(pSujeto_Id Number); 
  Procedure pro_Eliminar_Frac_Respuestas(pArticulo_Fraccion_Id Number);
  Procedure pro_Cargar_Solicitudes(pSujeto_Obligado_Id Number);
  Procedure pro_Asignar_Respuestas(pEvaluacion_Id Number);
  Procedure pro_Articulos_encuesta(pEvaluacion_Id Number,
                                  pArticulo_Id   Number);
                               
  Procedure pro_crear_encuesta(pEvaluacion_Id Number,
                               pSujeto_Obligado_Id Number);
  -------------------------------------------------------------------------
  Procedure pro_crear_encuesta_2017(pEvaluacion_Id      Number,
                                    pSujeto_Obligado_Id Number,
                                    pUsuario            Varchar2);   
  -------------------------------------------------------------------------                                  
  Procedure Pro_Actualizar_Fraccion(pEvaluacion_Fraccion_Id Number);     
  -------------------------------------------------------------------------
  Procedure Act_Eva_Fracciones(pEvaluacion_Articulo_Id Number,
                               pValoracion             Number);
  -------------------------------------------------------------------------                                
  Procedure pro_limpiar_encuesta_2017(pEvaluacion_Id Number);
                                                           
  Procedure pro_Copiar_encuesta(pEvaluacion_Id Number, 
                                 pPeriodo_Id   Number,
                                 pNewPeriodo_Id Number);                             
end pgk_idaip;
/
CREATE package body pgk_idaip is
 Procedure pro_Act_Sujetos_Fracciones(pSujeto_Id   Number,
                                      pArticulo_Id Number) Is
    Cursor cArtFracc Is Select * From Articulos_Fracciones
                            Where Articulo_Id  = pArticulo_Id;
   cArtFracc1 cArtFracc%Rowtype;
   nCont Number := 0;    
 Begin           
   Open cArtFracc;
   Loop
     Fetch cArtFracc Into cArtFracc1;
     Exit When cArtFracc%Notfound;     
     
     Select Count(1) Into nCont From  SUJETOS_FRACCIONES
       Where Articulo_Fraccion_Id = cArtFracc1.Articulo_Fraccion_Id
         And Sujeto_Obligado_Id   = pSujeto_Id;
   
     If nCont = 0 Then                              
       Insert Into SUJETOS_FRACCIONES
       (Articulo_Fraccion_Id, aplica, fecha_insert, usuario_insert, sujeto_obligado_id, Articulo_Id )
       Values
       (cArtFracc1.Articulo_Fraccion_Id, 0, Sysdate, 'DEV', pSujeto_Id,cArtFracc1.Articulo_Id );
     End If;
      
   End Loop;
   Close cArtFracc;
 End;  
 ---------------------------------------------------------------------------
 Procedure pro_Act_Sujetos_Articulos(pSujeto_Id Number) Is
   Cursor cSujetos Is Select Sujeto_Obligado_Id From Sujetos_Obligados
                           Where ( (Sujeto_Obligado_Id = pSujeto_Id) Or (pSujeto_Id = 0));
                       cSujetos1 cSujetos%Rowtype;    
   Cursor C1 Is Select * From Articulos
                  Where Activo = 1
                    And Estatus = 1;
    C2 C1%Rowtype;    
  nCont Number := 0;              
 Begin
   Open cSujetos;
   Loop
     Fetch cSujetos Into cSujetos1;
     Exit When cSujetos%Notfound;
     
     Open C1;
     Loop
       Fetch C1 Into C2;
       Exit When C1%Notfound;
       
       Select Count(1) Into nCont From SUJETOS_ARTICULOS
         Where Sujeto_Obligado_Id = cSujetos1.Sujeto_Obligado_Id
           And Articulo_Id = C2.ARTICULO_ID;
        
       If nCont = 0 Then
         Insert Into Sujetos_Articulos
         (sujeto_obligado_id, articulo_id, fecha_insert, usuario_insert, estatus )
         Values
         (cSujetos1.Sujeto_Obligado_Id, C2.Articulo_Id, Sysdate, 'DEV', 0);
       End If;     
       
       
       
     End Loop;
     Close C1;  
   End Loop;  
   Close cSujetos;
 End;
 -------------------------------------------------------------------------------    
 Procedure pro_Eliminar_Frac_Respuestas(pArticulo_Fraccion_Id Number) Is
 Begin  
   Delete  det_eval_fracciones
    Where art_fracc_respuesta_id In (
    Select art_fracc_respuesta_id  from ART_FRACC_RESPUESTAS 
       Where articulo_fraccion_id = pArticulo_Fraccion_Id
       );
   
   Delete ART_FRACC_RESPUESTAS
     Where ARTICULO_FRACCION_ID = pArticulo_Fraccion_Id;
     
 End;
     
 Procedure pro_Cargar_Solicitudes(pSujeto_Obligado_Id Number) Is
   Cursor C1 Is Select * From SOLICITUDES_TEMP
                   Where Sujeto_Obligado_Id = pSujeto_Obligado_Id;
  C2 C1%Rowtype;                
  nCont Number := 0; 
  tmpMensaje SOLICITUDES_TEMP.MENSAJE%Type;
  tmpMedio_solicita_Id Solicitudes_Informacion.Medio_Solicitud_Id%Type := 0;
  tmpGenero Solicitudes_Informacion.Genero_Solicitud%Type;
  tmpTipo_Informacion_Id Number := 0;
  tmpMedio_Entero Number := 0;
 Begin
   Open C1;
   Loop
     Fetch C1 Into C2;
     Exit When C1%Notfound;
     
     Select Count(1) Into nCont From Solicitudes_Informacion
        Where Sujeto_Obligado_Id = C2.Sujeto_Obligado_Id
          And Folio              = C2.FOLIO;
          
     If nCont = 0 Then      
      
      --------------Obtenemos el medio por el cual se hizo la solicitud--------------
      If (C2.Infomex Is Null) And
         (C2.CORREO  Is Null) And
         (C2.TELEFONO  Is Null) And
         (C2.Convencional  Is Null) Then
       
         tmpMedio_solicita_Id := 5;
      Else
        
         If C2.Infomex Is Not Null Then
           tmpMedio_solicita_Id := 4;
         End If;
         
         If C2.CORREO Is Not Null Then
           tmpMedio_solicita_Id := 1;
         End If;
         
         If C2.TELEFONO Is Not Null Then
           tmpMedio_solicita_Id := 2;
         End If;
         
         If C2.Convencional Is Not Null Then
           tmpMedio_solicita_Id := 3;
         End If;         
      
        
      End If;   
      ------------Terminamos la obtención del medio--------------
      
      -----------------Obtenemos el genero-----------------------
      If ( C2.Masculino Is NUll ) And (C2.FEMENINO Is Null) Then
        tmpGenero := Null;
      Else
        If C2.Masculino Is Not Null Then
          tmpGenero := 1;
        End If;
        
        If C2.FEMENINO Is Not Null Then
          tmpGenero := 2;
        End If;
        
      End If;  
      ------------------------Terminamos la obtención del genero-------------
      -----------------------------------------------------------------------
      --------------Obtenemos el tipo de información solicitada--------------
      If (C2.ti_f  Is Null) And
         (C2.ti_e   Is Null) And
         (C2.ti_n   Is Null) And
         (C2.ti_o   Is Null) And 
         (C2.TI_OTROS Is Null) Then
        
        tmpTipo_Informacion_Id := Null;
      
      Else  
         If C2.ti_f Is Not Null Then
           tmpTipo_Informacion_Id := 2;
         End If;
         
         If C2.ti_e  Is Not Null Then
           tmpTipo_Informacion_Id := 3;
         End If;
         
         If C2.ti_n  Is Not Null Then
           tmpTipo_Informacion_Id := 4;
         End If;
         
         If C2.ti_o  Is Not Null Then
           tmpTipo_Informacion_Id := 5;
         End If;
         
         If C2.ti_otros  Is Not Null Then
           tmpTipo_Informacion_Id := 6;
         End If;
       End If;   
      ------------Terminamos la obtención del tipo de información solicitada--------------
      ------------------------------------------------------------------------------------
      ------------Obtenemos el medio por el que se entero del IDAIP-----------------------
       If (C2.radio   Is Null) And
         (C2.tv    Is Null) And
         (C2.internet    Is Null) And
         (C2.idaip    Is Null) And 
         (C2.motros  Is Null) Then
        
        tmpMedio_Entero := Null;
      
      Else  
         If C2.radio  Is Not Null Then
           tmpMedio_Entero := 21;
         End If;
         
         If C2.tv   Is Not Null Then
           tmpMedio_Entero := 22;
         End If;
         
         If C2.internet   Is Not Null Then
           tmpMedio_Entero := 23;
         End If;
         
         If C2.idaip   Is Not Null Then
           tmpMedio_Entero := 24;
         End If;
         
         If C2.motros   Is Not Null Then
           tmpMedio_Entero := 25;
         End If;
       End If;  
      
      ------------------------------------------------------------------------------------
           
      Begin
        Insert Into Solicitudes_Informacion
        (sujeto_obligado_id, fecha,  folio, edad,fecha_atencion, 
         medio_solicitud_id, fecha_solicitud, genero_solicitud, tipo_informacion_id ,
         ocupacion, informacion_solicitada, num_ser_inv, prorroga, dias_transcurridos,
         medio_ent_idaip_id )
        Values
        (C2.sujeto_obligado_id, C2.FECHA, C2.FOLIO, C2.EDAD, C2.f_RESPUESTA,
         tmpMedio_solicita_Id ,  C2.FECHA, tmpGenero, tmpTipo_Informacion_Id,
         C2.OCUPACION, C2.Informacion, c2.num_servidores,
         NVL2( c2.prorroga, 1, 0 ),  c2.dias_transcurridos,
         tmpMedio_Entero);
         
         Update SOLICITUDES_TEMP
         Set Mensaje = 'Solicitud cargada'
         Where Solicitud_temp_id = C2.SOLICITUD_TEMP_ID;
         
         Exception
         When Others Then
         tmpMensaje := substr(sqlerrm, 1,150);
         
         Update SOLICITUDES_TEMP
         Set Mensaje = tmpMensaje
         Where Solicitud_temp_id = C2.SOLICITUD_TEMP_ID;
       End;
     Else
       Update SOLICITUDES_TEMP
       Set Mensaje = 'Ya existe una solicitud con este folio'
       Where Solicitud_temp_id = C2.SOLICITUD_TEMP_ID;
     End If;
          
   End Loop;
   Close C1;
 End;
 
 Procedure pro_Asignar_Respuestas(pEvaluacion_Id Number) Is
   tmpCadena Varchar2(2000);
   myToken   Varchar2(20);
   myId      Number := 0;
   myValor   Varchar2(10);
   nCont     Number := 0;
 Begin
   Select Trim(respuestas) Into tmpCadena  From Evaluaciones
     Where Evaluacion_Id = pEvaluacion_Id;
   
   Loop
     Exit When ( (length (tmpCadena) < 3) Or  (nCont=50));
     nCont := nCont + 1;
     dbms_output.put_line(tmpCadena);
     myToken := Substr(tmpCadena, 1, Instr(tmpCadena,';')); 
     myId := Trim(Substr(myToken, 1, Instr(myToken,' ')));
     myValor := Replace(Trim(Substr(myToken, Instr(myToken,' '))),';','');
     dbms_output.put_line(myToken || '('|| myId ||' ' || myValor || ')');
     tmpCadena := substr(tmpCadena, Instr(tmpCadena,';') + 1 );
     
     If myId Is Not Null Then
       Update det_eval_fracciones
       Set respuesta = myValor
       Where det_eval_fraccion_id = myId;
     End If;
     
   End Loop;  
 End;
 ---------------------------------------------------------
 Procedure pro_Articulos_encuesta(pEvaluacion_Id Number,
                                  pArticulo_Id   Number) Is
   Cursor C1(prmArticulo_Id  Number) Is 
         Select * From ARTICULOS_FRACCIONES 
             Where Articulo_Id = prmArticulo_Id
               And Estatus = 1;
    C2 C1%Rowtype;  
    
  Cursor cRespuestas(pArticulo_Fraccion_id Number) Is 
     Select respuesta, valor, orden,  ART_FRACC_RESPUESTA_ID from Art_Fracc_Respuestas
      Where articulo_fraccion_id = pArticulo_Fraccion_id 
        And Estatus = 1
     Order by Orden;
   cRespuestas1 cRespuestas%Rowtype;  
   nSeq Number := 0;                                     
 Begin
   Open C1(pArticulo_Id);
   Loop
     Fetch C1 Into C2;
     Exit When C1%notfound;
     select "EVALUACIONES_FRACCIONES_SEQ".nextval into nSeq from sys.dual; 
  
     Insert Into EVALUACIONES_FRACCIONES
     (evaluacion_fraccion_id, evaluacion_id, articulo_fraccion_id, respuesta,
      comentario, fecha_insert )
     Values
     (nSeq,pevaluacion_id, C2.articulo_fraccion_id, null,
      '', Sysdate );
      
     Open cRespuestas(C2.Articulo_fraccion_id);
     Loop
       Fetch cRespuestas Into cRespuestas1;
       Exit When cRespuestas%Notfound;
       
       Insert Into DET_EVAL_FRACCIONES
       (Evaluacion_fraccion_id, 
        Art_fracc_respuesta_id,
        respuesta, 
        fecha, usuario_insert )
       Values
       (nSeq, 
        cRespuestas1.art_fracc_respuesta_id,
        0, 
        Sysdate, 'IDAIP');
     End Loop;
     Close cRespuestas;
      
   End Loop;
   Close C1;  
 End;
                                  
 Procedure pro_crear_encuesta(pEvaluacion_Id Number,
                              pSujeto_Obligado_Id Number) Is
   Cursor C1(prmSujeto_Obligado_Id Number) Is 
        Select a.Articulo_Id, a.descripcion From SUJETOS_ARTICULOS soa , Articulos a
              Where soa.Sujeto_Obligado_Id = prmSujeto_Obligado_Id
                And a.Articulo_Id         = soa.Articulo_Id
                And soa.estatus           = 1
            Union
            Select a.Articulo_Id, a.descripcion From Sujetos_Obligados_Articulos soa, Sujetos_Obligados so, Articulos a
             Where soa.tipo_sujeto_obligado_id  = so.tipo_sujeto_obligado_id 
               And so.sujeto_obligado_id = prmSujeto_Obligado_Id
               And a.Articulo_Id         = soa.Articulo_Id
               And 2 = 1; 
           --Select sua.* From SUJETOS_ARTICULOS sua
           --        Where sua.Sujeto_Obligado_Id = prmSujeto_Obligado_Id;
     C2 C1%Rowtype;                      
 Begin
   Open C1(pSujeto_Obligado_Id);
   Loop
     Fetch C1 Into C2;
     Exit When C1%Notfound;
     pro_Articulos_encuesta(pEvaluacion_Id, C2.ARTICULO_ID);
   End Loop;
   Close C1;
 End;
 -------------------------------------------------------------------------------------------
 --*****************************************************************************************
 -------------------------Procedimientos nuevos-----------------------------------------------
 --*****************************************************************************************
 -------------------------------------------------------------------------------------------
 Procedure pro_crear_encuesta_2017(pEvaluacion_Id      Number,
                                   pSujeto_Obligado_Id Number,
                                   pUsuario            Varchar2) Is
   Cursor C1 Is Select a.articulo_id   From Sujetos_Articulos soa, Articulos a
                 Where soa.sujeto_obligado_id = pSujeto_Obligado_Id
                   And a.Articulo_id         = soa.articulo_id
                   And a.Activo              = 1
                   And soa.Estatus           = 1;           
     C2 C1%Rowtype;    
     
   Cursor cFracciones(prmArticulo_Id Number,
                      prmSujeto_Id   Number) Is 
                 Select * From Sujetos_Fracciones
                   Where Articulo_Id        = prmArticulo_Id
                     And Sujeto_Obligado_Id = prmSujeto_Id
                     And Aplica             = 1;
       cFracciones1 cFracciones%Rowtype;  
   
   Cursor cRespuestas(pArticulo_Fraccion_id Number) Is 
     Select respuesta, tipo_criterio_id , orden,  ART_FRACC_RESPUESTA_ID from Art_Fracc_Respuestas
      Where articulo_fraccion_id = pArticulo_Fraccion_id 
        And Estatus = 1
     Order by Orden;
   cRespuestas1 cRespuestas%Rowtype;
                   
   nCont Number := 0;        
   nSeq  Number := 0;         
   nSeq2 Number := 0;   
 Begin
   Open C1;
   Loop
     Fetch C1 Into C2;
     Exit When C1%Notfound;
       Select Count(1) Into nCont From Evaluaciones_Articulos
         Where Articulo_Id    = C2.ARTICULO_ID
           And Evaluacion_Id  = pEvaluacion_Id;
       
       If nCont = 0 Then 
         select "EVALUACION_ARTICULOS_SEQ".nextval into nSeq from sys.dual; 
         Insert Into Evaluaciones_Articulos
         (evaluacion_articulo_id, Evaluacion_id, articulo_id, estatus, fecha_insert, usuario_insert )
         Values
         (nSeq, pEvaluacion_Id, C2.ARTICULO_ID, 1, Sysdate, pUsuario);
         
          Open cFracciones(C2.ARTICULO_ID, pSujeto_Obligado_Id);
          Loop
            Fetch cFracciones Into cFracciones1;
            Exit When cFracciones%Notfound;
            
            select "EVALUACIONES_FRACCIONES_SEQ".nextval into nSeq2 from sys.dual; 
            
            Insert Into Evaluaciones_Fracciones
            (evaluacion_fraccion_id, Evaluacion_Id, articulo_fraccion_id, fecha_insert, Evaluacion_Articulo_Id )
            Values
            (nSeq2, pEvaluacion_Id, cFracciones1.Articulo_fraccion_id, Sysdate, nSeq);
            -------------------------------------------------------------------
            ----------------------Población de las preguntas-------------------
            -------------------------------------------------------------------
            Open cRespuestas(cFracciones1.Articulo_fraccion_id);
            Loop
               Fetch cRespuestas Into cRespuestas1;
               Exit When cRespuestas%Notfound;
               
               Insert Into DET_EVAL_FRACCIONES
               (Evaluacion_fraccion_id, 
                Art_fracc_respuesta_id,
                respuesta, 
                fecha, usuario_insert,tipo_criterio_id  )
               Values
               (nSeq2, 
                cRespuestas1.art_fracc_respuesta_id,
                0, 
                Sysdate, 'IDAIP', cRespuestas1.tipo_criterio_id);
            End Loop;
            Close cRespuestas;
     
            
          End Loop;
          Close cFracciones;  
       End If;
        
   End Loop;
   Close C1;
 End;
 ------------------------------------------------------------------------------------------------------
 Procedure Pro_Actualizar_Fraccion(pEvaluacion_Fraccion_Id Number) Is   
  tmpSustantivos Number := 0;
  tmpAdjetivos   Number := 0;
Begin
  Select Round( ((sum(decode(nvl(d.respuesta,0), 0, 0,.9,1, d.respuesta)) * 100 )/ count(1)),2)  Into tmpSustantivos
       From Det_Eval_Fracciones d, Evaluaciones_Fracciones ef
         Where d.evaluacion_fraccion_id = ef.Evaluacion_Fraccion_Id
           And ef.Evaluacion_Fraccion_Id = pEvaluacion_Fraccion_Id
           And Tipo_Criterio_Id = 1
        Group BY ef.Evaluacion_Fraccion_Id;

 Select Round( ((sum(decode(nvl(d.respuesta,0), 0, 0,.9,1, d.respuesta)) * 100 )/ count(1)),2)  Into tmpAdjetivos
       From Det_Eval_Fracciones d, Evaluaciones_Fracciones ef
         Where d.evaluacion_fraccion_id = ef.Evaluacion_Fraccion_Id
           And ef.Evaluacion_Fraccion_Id = pEvaluacion_Fraccion_Id
           And Tipo_Criterio_Id = 2
        Group BY ef.Evaluacion_Fraccion_Id;


   Update Evaluaciones_Fracciones
   Set Prom_Sustantivos = tmpSustantivos, 
       Prom_Adjetivos   = tmpAdjetivos
   Where Evaluacion_Fraccion_Id = pEvaluacion_Fraccion_Id;
End;
-----------------------------------------------------------------------------------------
Procedure Act_Eva_Fracciones(pEvaluacion_Articulo_Id Number,
                             pValoracion             Number) Is
  Cursor C1 Is Select * From Evaluaciones_Fracciones
                Where Evaluacion_Articulo_Id = pEvaluacion_Articulo_Id;
  C2 C1%Rowtype;              
Begin  
  Open C1;
  Loop
    Fetch C1 Into C2;
    Exit When C1%Notfound;
  
    Update DET_EVAL_FRACCIONES
    Set Respuesta = pValoracion
    Where EVALUACION_FRACCION_ID = C2.EVALUACION_FRACCION_ID;
    Pro_Actualizar_Fraccion(C2.EVALUACION_FRACCION_ID);
  End Loop;
  Close C1;  
 
End;  
-----------------------------------------------------------------------------------------
 Procedure pro_limpiar_encuesta_2017(pEvaluacion_Id Number) Is  
  
 Begin            
    Delete DET_EVAL_FRACCIONES
    Where Evaluacion_Fraccion_id In ( Select Evaluacion_Fraccion_id From Evaluaciones_Fracciones ef, Evaluaciones_Articulos ea
                                          Where ef.Evaluacion_Articulo_Id = ef.Evaluacion_Articulo_Id
                                            And ea.Evaluacion_Id = pEvaluacion_Id);
                                                    
    Delete Evaluaciones_Fracciones
    Where Evaluacion_Fraccion_id In ( Select Evaluacion_Fraccion_id From Evaluaciones_Fracciones ef, Evaluaciones_Articulos ea
                                          Where ef.Evaluacion_Articulo_Id = ef.Evaluacion_Articulo_Id
                                            And ea.Evaluacion_Id = pEvaluacion_Id);
                                                    
            
    Delete Evaluaciones_Articulos
    Where Evaluacion_id = pEvaluacion_Id;           
   
 End;
-------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------- 
 Procedure pro_Copiar_encuesta(pEvaluacion_Id Number, 
                               pPeriodo_Id    Number,
                               pNewPeriodo_Id Number) Is   
  
   Cursor cCop_Eva_Fracciones(prmEvaluacion_Id Number) Is 
           Select * From EVALUACIONES_FRACCIONES
              Where Evaluacion_Id = prmEvaluacion_Id;
    cCop_Eva_Fracciones1 cCop_Eva_Fracciones%Rowtype;
    
   Cursor cArticulos(prmSujeto_Obligado_Id Number) Is 
   
              Select sua.* From SUJETOS_ARTICULOS sua
                   Where sua.Sujeto_Obligado_Id = prmSujeto_Obligado_Id;
     cArticulos1 cArticulos%Rowtype;
                                               
   Cursor C1(prmArticulo_Id  Number) Is 
         Select * From ARTICULOS_FRACCIONES 
             Where Articulo_Id = prmArticulo_Id
               And Estatus = 1;
    C2 C1%Rowtype;  
    
  Cursor cRespuestas(pEvaluacion_fraccion_id Number) Is select * from DET_EVAL_FRACCIONES
     Where Evaluacion_Fraccion_Id  = pEvaluacion_fraccion_id; 
      
   cRespuestas1 cRespuestas%Rowtype;  
   nSeq Number := 0;       
   nCont Number := 0;        
   tmpSujeto_Id    Number := 0;       
   nEvaluacion_Id  Number := 0;               
 Begin
  Select sujeto_obligado_id Into tmpSujeto_Id From Evaluaciones 
      Where Evaluacion_Id = pEvaluacion_Id;      
      
  Select Count(1) Into nCont From Evaluaciones
    Where periodo_id         = pNewPeriodo_Id
      And Sujeto_Obligado_Id = tmpSujeto_Id;
  
  If nCont = 0 Then
    Select "EVALUACIONES_SEQ".nextval into nEvaluacion_Id from sys.dual; 
    
    Insert Into Evaluaciones
    (evaluacion_id, periodo_id, sujeto_obligado_id, articulo_id,
     fecha_evaluacion, usuario_evalua, estatus, respuestas,
     tipo_evaluacion, cierre, resultado  )
    Select nEvaluacion_Id, pNewPeriodo_Id, sujeto_obligado_id, articulo_id,
     Sysdate, usuario_evalua, estatus, respuestas,
     tipo_evaluacion, cierre, resultado
     From Evaluaciones
    Where Evaluacion_Id = pEvaluacion_Id; 
    
    Open cCop_Eva_Fracciones(pEvaluacion_Id);   
    Loop
      Fetch cCop_Eva_Fracciones Into cCop_Eva_Fracciones1;
      Exit When cCop_Eva_Fracciones%notfound;
       
         --Open C1(cArticulos1.Articulo_Id);
         --Loop
         --  Fetch C1 Into C2;
         --  Exit When C1%notfound;
           select "EVALUACIONES_FRACCIONES_SEQ".nextval into nSeq from sys.dual; 
        
           Insert Into EVALUACIONES_FRACCIONES
           (evaluacion_fraccion_id, evaluacion_id, articulo_fraccion_id, respuesta,
            comentario, fecha_insert )
           Values
           (nSeq, nEvaluacion_Id, cCop_Eva_Fracciones1.articulo_fraccion_id, cCop_Eva_Fracciones1.Respuesta,
            cCop_Eva_Fracciones1.Comentario, Sysdate );
            
           Open cRespuestas(cCop_Eva_Fracciones1.evaluacion_fraccion_id);
           Loop
             Fetch cRespuestas Into cRespuestas1;
             Exit When cRespuestas%Notfound;
             
             Insert Into DET_EVAL_FRACCIONES
             (Evaluacion_fraccion_id, 
              Art_fracc_respuesta_id,
              respuesta, 
              fecha, usuario_insert )
              Values
              (nSeq, 
               cRespuestas1.art_fracc_respuesta_id,
               cRespuestas1.Respuesta, 
               Sysdate, 'IDAIP');
           End Loop;
           Close cRespuestas;
            
         --End Loop;
         --Close C1;  
       End Loop;
       Close cCop_Eva_Fracciones;  
   End If;
   
 End;
end pgk_idaip;
/
/
