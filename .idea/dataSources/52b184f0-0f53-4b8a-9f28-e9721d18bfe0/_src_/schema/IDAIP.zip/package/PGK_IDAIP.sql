CREATE package pgk_idaip is
  Procedure pro_Eliminar_Frac_Respuestas(pArticulo_Fraccion_Id Number);
  Procedure pro_Cargar_Solicitudes(pSujeto_Obligado_Id Number);
  Procedure pro_Asignar_Respuestas(pEvaluacion_Id Number);
  Procedure pro_Articulos_encuesta(pEvaluacion_Id Number,
                                  pArticulo_Id   Number);
                               
  Procedure pro_crear_encuesta(pEvaluacion_Id Number,
                               pSujeto_Obligado_Id Number);
  Procedure pro_Copiar_encuesta(pEvaluacion_Id Number, 
                                 pPeriodo_Id   Number,
                                 pNewPeriodo_Id Number);                             
end pgk_idaip;
/
