CREATE package pgk_idaip is
  Procedure pro_Eliminar_Frac_Respuestas(pArticulo_Fraccion_Id Number);
  Procedure pro_Cargar_Solicitudes(pSujeto_Obligado_Id Number);
  Procedure pro_Asignar_Respuestas(pEvaluacion_Id Number);
  Procedure pro_Articulos_encuesta(pEvaluacion_Id Number,
                                  pArticulo_Id   Number);
                               
  Procedure pro_crear_encuesta(pEvaluacion_Id Number,
                               pSujeto_Obligado_Id Number);
  Procedure pro_Copiar_encuesta(pEvaluacion_Id Number, 
                                 pPeriodo_Id   Number,
                                 pNewPeriodo_Id Number);                             
end pgk_idaip;
/
CREATE package body pgk_idaip is
 Procedure pro_Eliminar_Frac_Respuestas(pArticulo_Fraccion_Id Number) Is
 Begin  
   Delete  det_eval_fracciones
    Where art_fracc_respuesta_id In (
    Select art_fracc_respuesta_id  from ART_FRACC_RESPUESTAS 
       Where articulo_fraccion_id = pArticulo_Fraccion_Id
       );
   
   Delete ART_FRACC_RESPUESTAS
     Where ARTICULO_FRACCION_ID = pArticulo_Fraccion_Id;
     
 End;
     
 Procedure pro_Cargar_Solicitudes(pSujeto_Obligado_Id Number) Is
   Cursor C1 Is Select * From SOLICITUDES_TEMP
                   Where Sujeto_Obligado_Id = pSujeto_Obligado_Id;
  C2 C1%Rowtype;                
  nCont Number := 0; 
  tmpMensaje SOLICITUDES_TEMP.MENSAJE%Type;
  tmpMedio_solicita_Id Solicitudes_Informacion.Medio_Solicitud_Id%Type := 0;
  tmpGenero Solicitudes_Informacion.Genero_Solicitud%Type;
  tmpTipo_Informacion_Id Number := 0;
  tmpMedio_Entero Number := 0;
 Begin
   Open C1;
   Loop
     Fetch C1 Into C2;
     Exit When C1%Notfound;
     
     Select Count(1) Into nCont From Solicitudes_Informacion
        Where Sujeto_Obligado_Id = C2.Sujeto_Obligado_Id
          And Folio              = C2.FOLIO;
          
     If nCont = 0 Then      
      
      --------------Obtenemos el medio por el cual se hizo la solicitud--------------
      If (C2.Infomex Is Null) And
         (C2.CORREO  Is Null) And
         (C2.TELEFONO  Is Null) And
         (C2.Convencional  Is Null) Then
       
         tmpMedio_solicita_Id := 5;
      Else
        
         If C2.Infomex Is Not Null Then
           tmpMedio_solicita_Id := 4;
         End If;
         
         If C2.CORREO Is Not Null Then
           tmpMedio_solicita_Id := 1;
         End If;
         
         If C2.TELEFONO Is Not Null Then
           tmpMedio_solicita_Id := 2;
         End If;
         
         If C2.Convencional Is Not Null Then
           tmpMedio_solicita_Id := 3;
         End If;         
      
        
      End If;   
      ------------Terminamos la obtención del medio--------------
      
      -----------------Obtenemos el genero-----------------------
      If ( C2.Masculino Is NUll ) And (C2.FEMENINO Is Null) Then
        tmpGenero := Null;
      Else
        If C2.Masculino Is Not Null Then
          tmpGenero := 1;
        End If;
        
        If C2.FEMENINO Is Not Null Then
          tmpGenero := 2;
        End If;
        
      End If;  
      ------------------------Terminamos la obtención del genero-------------
      -----------------------------------------------------------------------
      --------------Obtenemos el tipo de información solicitada--------------
      If (C2.ti_f  Is Null) And
         (C2.ti_e   Is Null) And
         (C2.ti_n   Is Null) And
         (C2.ti_o   Is Null) And 
         (C2.TI_OTROS Is Null) Then
        
        tmpTipo_Informacion_Id := Null;
      
      Else  
         If C2.ti_f Is Not Null Then
           tmpTipo_Informacion_Id := 2;
         End If;
         
         If C2.ti_e  Is Not Null Then
           tmpTipo_Informacion_Id := 3;
         End If;
         
         If C2.ti_n  Is Not Null Then
           tmpTipo_Informacion_Id := 4;
         End If;
         
         If C2.ti_o  Is Not Null Then
           tmpTipo_Informacion_Id := 5;
         End If;
         
         If C2.ti_otros  Is Not Null Then
           tmpTipo_Informacion_Id := 6;
         End If;
       End If;   
      ------------Terminamos la obtención del tipo de información solicitada--------------
      ------------------------------------------------------------------------------------
      ------------Obtenemos el medio por el que se entero del IDAIP-----------------------
       If (C2.radio   Is Null) And
         (C2.tv    Is Null) And
         (C2.internet    Is Null) And
         (C2.idaip    Is Null) And 
         (C2.motros  Is Null) Then
        
        tmpMedio_Entero := Null;
      
      Else  
         If C2.radio  Is Not Null Then
           tmpMedio_Entero := 21;
         End If;
         
         If C2.tv   Is Not Null Then
           tmpMedio_Entero := 22;
         End If;
         
         If C2.internet   Is Not Null Then
           tmpMedio_Entero := 23;
         End If;
         
         If C2.idaip   Is Not Null Then
           tmpMedio_Entero := 24;
         End If;
         
         If C2.motros   Is Not Null Then
           tmpMedio_Entero := 25;
         End If;
       End If;  
      
      ------------------------------------------------------------------------------------
           
      Begin
        Insert Into Solicitudes_Informacion
        (sujeto_obligado_id, fecha,  folio, edad,fecha_atencion, 
         medio_solicitud_id, fecha_solicitud, genero_solicitud, tipo_informacion_id ,
         ocupacion, informacion_solicitada, num_ser_inv, prorroga, dias_transcurridos,
         medio_ent_idaip_id )
        Values
        (C2.sujeto_obligado_id, C2.FECHA, C2.FOLIO, C2.EDAD, C2.f_RESPUESTA,
         tmpMedio_solicita_Id ,  C2.FECHA, tmpGenero, tmpTipo_Informacion_Id,
         C2.OCUPACION, C2.Informacion, c2.num_servidores,
         NVL2( c2.prorroga, 1, 0 ),  c2.dias_transcurridos,
         tmpMedio_Entero);
         
         Update SOLICITUDES_TEMP
         Set Mensaje = 'Solicitud cargada'
         Where Solicitud_temp_id = C2.SOLICITUD_TEMP_ID;
         
         Exception
         When Others Then
         tmpMensaje := substr(sqlerrm, 1,150);
         
         Update SOLICITUDES_TEMP
         Set Mensaje = tmpMensaje
         Where Solicitud_temp_id = C2.SOLICITUD_TEMP_ID;
       End;
     Else
       Update SOLICITUDES_TEMP
       Set Mensaje = 'Ya existe una solicitud con este folio'
       Where Solicitud_temp_id = C2.SOLICITUD_TEMP_ID;
     End If;
          
   End Loop;
   Close C1;
 End;
 
 Procedure pro_Asignar_Respuestas(pEvaluacion_Id Number) Is
   tmpCadena Varchar2(2000);
   myToken   Varchar2(20);
   myId      Number := 0;
   myValor   Varchar2(10);
   nCont     Number := 0;
 Begin
   Select Trim(respuestas) Into tmpCadena  From Evaluaciones
     Where Evaluacion_Id = pEvaluacion_Id;
   
   Loop
     Exit When ( (length (tmpCadena) < 3) Or  (nCont=50));
     nCont := nCont + 1;
     dbms_output.put_line(tmpCadena);
     myToken := Substr(tmpCadena, 1, Instr(tmpCadena,';')); 
     myId := Trim(Substr(myToken, 1, Instr(myToken,' ')));
     myValor := Replace(Trim(Substr(myToken, Instr(myToken,' '))),';','');
     dbms_output.put_line(myToken || '('|| myId ||' ' || myValor || ')');
     tmpCadena := substr(tmpCadena, Instr(tmpCadena,';') + 1 );
     
     If myId Is Not Null Then
       Update det_eval_fracciones
       Set respuesta = myValor
       Where det_eval_fraccion_id = myId;
     End If;
     
   End Loop;  
 End;
 ---------------------------------------------------------
 Procedure pro_Articulos_encuesta(pEvaluacion_Id Number,
                                  pArticulo_Id   Number) Is
   Cursor C1(prmArticulo_Id  Number) Is 
         Select * From ARTICULOS_FRACCIONES 
             Where Articulo_Id = prmArticulo_Id
               And Estatus = 1;
    C2 C1%Rowtype;  
    
  Cursor cRespuestas(pArticulo_Fraccion_id Number) Is select respuesta, valor, orden,  ART_FRACC_RESPUESTA_ID from art_fracc_respuestas
     Where articulo_fraccion_id = pArticulo_Fraccion_id 
       And Estatus = 1
     Order by Orden;
   cRespuestas1 cRespuestas%Rowtype;  
   nSeq Number := 0;                                     
 Begin
   Open C1(pArticulo_Id);
   Loop
     Fetch C1 Into C2;
     Exit When C1%notfound;
     select "EVALUACIONES_FRACCIONES_SEQ".nextval into nSeq from sys.dual; 
  
     Insert Into EVALUACIONES_FRACCIONES
     (evaluacion_fraccion_id, evaluacion_id, articulo_fraccion_id, respuesta,
      comentario, fecha_insert )
     Values
     (nSeq,pevaluacion_id, C2.articulo_fraccion_id, null,
      '', Sysdate );
      
     Open cRespuestas(C2.Articulo_fraccion_id);
     Loop
       Fetch cRespuestas Into cRespuestas1;
       Exit When cRespuestas%Notfound;
       
       Insert Into DET_EVAL_FRACCIONES
       (Evaluacion_fraccion_id, 
        Art_fracc_respuesta_id,
        respuesta, 
        fecha, usuario_insert )
       Values
       (nSeq, 
        cRespuestas1.art_fracc_respuesta_id,
        0, 
        Sysdate, 'IDAIP');
     End Loop;
     Close cRespuestas;
      
   End Loop;
   Close C1;  
 End;
                                  
 Procedure pro_crear_encuesta(pEvaluacion_Id Number,
                              pSujeto_Obligado_Id Number) Is
   Cursor C1(prmSujeto_Obligado_Id Number) Is 
        Select a.Articulo_Id, a.descripcion From SUJETOS_ARTICULOS soa , Articulos a
              Where soa.Sujeto_Obligado_Id = prmSujeto_Obligado_Id
                And a.Articulo_Id         = soa.Articulo_Id
                And soa.estatus           = 1
            Union
            Select a.Articulo_Id, a.descripcion From Sujetos_Obligados_Articulos soa, Sujetos_Obligados so, Articulos a
             Where soa.tipo_sujeto_obligado_id  = so.tipo_sujeto_obligado_id 
               And so.sujeto_obligado_id = prmSujeto_Obligado_Id
               And a.Articulo_Id         = soa.Articulo_Id
               And 2 = 1; 
           --Select sua.* From SUJETOS_ARTICULOS sua
           --        Where sua.Sujeto_Obligado_Id = prmSujeto_Obligado_Id;
     C2 C1%Rowtype;                      
 Begin
   Open C1(pSujeto_Obligado_Id);
   Loop
     Fetch C1 Into C2;
     Exit When C1%Notfound;
     pro_Articulos_encuesta(pEvaluacion_Id, C2.ARTICULO_ID);
   End Loop;
   Close C1;
 End;
--------------------------------------------------------------------------------------------- 
 Procedure pro_Copiar_encuesta(pEvaluacion_Id Number, 
                               pPeriodo_Id    Number,
                               pNewPeriodo_Id Number) Is   
  
   Cursor cCop_Eva_Fracciones(prmEvaluacion_Id Number) Is 
           Select * From EVALUACIONES_FRACCIONES
              Where Evaluacion_Id = prmEvaluacion_Id;
    cCop_Eva_Fracciones1 cCop_Eva_Fracciones%Rowtype;
    
   Cursor cArticulos(prmSujeto_Obligado_Id Number) Is 
   
              Select sua.* From SUJETOS_ARTICULOS sua
                   Where sua.Sujeto_Obligado_Id = prmSujeto_Obligado_Id;
     cArticulos1 cArticulos%Rowtype;
                                               
   Cursor C1(prmArticulo_Id  Number) Is 
         Select * From ARTICULOS_FRACCIONES 
             Where Articulo_Id = prmArticulo_Id
               And Estatus = 1;
    C2 C1%Rowtype;  
    
  Cursor cRespuestas(pEvaluacion_fraccion_id Number) Is select * from DET_EVAL_FRACCIONES
     Where Evaluacion_Fraccion_Id  = pEvaluacion_fraccion_id; 
      
   cRespuestas1 cRespuestas%Rowtype;  
   nSeq Number := 0;       
   nCont Number := 0;        
   tmpSujeto_Id    Number := 0;       
   nEvaluacion_Id  Number := 0;               
 Begin
  Select sujeto_obligado_id Into tmpSujeto_Id From Evaluaciones 
      Where Evaluacion_Id = pEvaluacion_Id;      
      
  Select Count(1) Into nCont From Evaluaciones
    Where periodo_id         = pNewPeriodo_Id
      And Sujeto_Obligado_Id = tmpSujeto_Id;
  
  If nCont = 0 Then
    Select "EVALUACIONES_SEQ".nextval into nEvaluacion_Id from sys.dual; 
    
    Insert Into Evaluaciones
    (evaluacion_id, periodo_id, sujeto_obligado_id, articulo_id,
     fecha_evaluacion, usuario_evalua, estatus, respuestas,
     tipo_evaluacion, cierre, resultado  )
    Select nEvaluacion_Id, pNewPeriodo_Id, sujeto_obligado_id, articulo_id,
     Sysdate, usuario_evalua, estatus, respuestas,
     tipo_evaluacion, cierre, resultado
     From Evaluaciones
    Where Evaluacion_Id = pEvaluacion_Id; 
    
    Open cCop_Eva_Fracciones(pEvaluacion_Id);   
    Loop
      Fetch cCop_Eva_Fracciones Into cCop_Eva_Fracciones1;
      Exit When cCop_Eva_Fracciones%notfound;
       
         --Open C1(cArticulos1.Articulo_Id);
         --Loop
         --  Fetch C1 Into C2;
         --  Exit When C1%notfound;
           select "EVALUACIONES_FRACCIONES_SEQ".nextval into nSeq from sys.dual; 
        
           Insert Into EVALUACIONES_FRACCIONES
           (evaluacion_fraccion_id, evaluacion_id, articulo_fraccion_id, respuesta,
            comentario, fecha_insert )
           Values
           (nSeq, nEvaluacion_Id, cCop_Eva_Fracciones1.articulo_fraccion_id, cCop_Eva_Fracciones1.Respuesta,
            cCop_Eva_Fracciones1.Comentario, Sysdate );
            
           Open cRespuestas(cCop_Eva_Fracciones1.evaluacion_fraccion_id);
           Loop
             Fetch cRespuestas Into cRespuestas1;
             Exit When cRespuestas%Notfound;
             
             Insert Into DET_EVAL_FRACCIONES
             (Evaluacion_fraccion_id, 
              Art_fracc_respuesta_id,
              respuesta, 
              fecha, usuario_insert )
              Values
              (nSeq, 
               cRespuestas1.art_fracc_respuesta_id,
               cRespuestas1.Respuesta, 
               Sysdate, 'IDAIP');
           End Loop;
           Close cRespuestas;
            
         --End Loop;
         --Close C1;  
       End Loop;
       Close cCop_Eva_Fracciones;  
   End If;
   
 End;
end pgk_idaip;
/
/
