CREATE function fun_obt_porc_Art_Eva(pEvaluacion_Id Number,
                                                pArticulo_Id   Number) return integer is

  nResultado Number := 0;
begin

   Select Round(avg(Porcentaje)) Into nResultado From
   (
   Select fun_obt_porcentaje(ef.articulo_fraccion_id, ef.respuesta) Porcentaje
      from EVALUACIONES_FRACCIONES ef, articulos_fracciones af
    Where Evaluacion_id = pEvaluacion_Id
      And ef.Articulo_Fraccion_Id = af.Articulo_Fraccion_Id
      And af.Articulo_Id          = pArticulo_Id
    );


  Return nResultado;

end fun_obt_porc_Art_Eva;
/
