CREATE FUNCTION fun_obt_porc_Articulo_Fracc(pEvaluacion_articulo_id Number,
                                                       pTipo_Criterio          Number)
   RETURN Number IS
  nResultado NUMBER := 0;
  tmpSustantivo Number := 0;
  tmpAdjetivo   Number := 0;
BEGIN
  If pTipo_Criterio = 1 Then
    Select Avg(Nvl(prom_sustantivos,0)) Into nResultado
         From Evaluaciones_Fracciones
    Where evaluacion_articulo_id =  pEvaluacion_articulo_id;
  ElsIf pTipo_Criterio = 2 Then
    Select Avg(Nvl(prom_adjetivos,0)) Into nResultado
         From Evaluaciones_Fracciones
    Where evaluacion_articulo_id =  pEvaluacion_articulo_id;
  End If;


  RETURN Round(nResultado,2);

END fun_obt_porc_Articulo_Fracc;
/
