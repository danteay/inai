CREATE function app_auth (p_username in VARCHAR2,
                                     p_password in VARCHAR2)
return BOOLEAN
is
  l_password varchar2(4000);
  l_stored_password varchar2(4000);
  l_expires_on date;
  l_count number; 
begin

  select count(*)
  into l_count
  from Usuarios_Sistema
  where upper(usuario_sistema_clave ) = upper(p_username);

  if l_count > 0 then
    
     select Count(1) Into l_count from Usuarios_Sistema us, roles_usuario ru, roles_sistema rs
      Where us.usuario_sistema_id = ru.Usuario_Sistema_Id
        And ru.Rol_Sistema_Id     = rs.Rol_Sistema_Id
        And rs.Rol_Sistema_Clave  = 'ADMIN'
        And upper(usuario_sistema_clave ) = upper(p_username);
    
      
      If l_count >0 Then
        select passw
        into l_stored_password
        from Usuarios_Sistema
        where upper(usuario_sistema_clave) = upper(p_username);
        
        l_password := app_hash(p_username, l_stored_password);
      
        if l_stored_password = p_password then
          return true;
        else
          return false;
        end if;
      Else
        return false;
      End If;
       
      else
        return false;
      end if;
   

end;
/
