CREATE FUNCTION fun_obt_porcentaje(
  pArticulo_Fraccion_Id NUMBER,
  pValor NUMBER
) RETURN INTEGER IS
  nMax NUMBER := 0;
  nResultado NUMBER := 0;
BEGIN
  
  SELECT max(valor) INTO nMax FROM Art_Fracc_Respuestas
     WHERE Articulo_Fraccion_Id = pArticulo_Fraccion_Id;
     
  nResultado := trunc((pValor * 100) / nMax);
  
  RETURN nResultado;
 
END fun_obt_porcentaje;
/
