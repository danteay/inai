CREATE FUNCTION fun_obt_porc_fracc_crit(pEvaluacion_Fraccion_Id Number,
                                                   pTipo_Criterio_Id       Number)
   RETURN Number IS
  nResultado NUMBER := 0;
BEGIN

 Select Round( ((sum(decode(nvl(d.respuesta,0), 0, 0,.9,1, d.respuesta)) * 100 )/ count(1)),2) Into nResultado
       From Det_Eval_Fracciones d, Evaluaciones_Fracciones ef
         Where d.evaluacion_fraccion_id = ef.Evaluacion_Fraccion_Id
           And ef.Evaluacion_Fraccion_Id = pEvaluacion_Fraccion_Id
           And Tipo_Criterio_Id = pTipo_Criterio_Id
        Group BY ef.Evaluacion_Fraccion_Id;

  RETURN Round(nResultado,2);

END fun_obt_porc_fracc_crit;
/
