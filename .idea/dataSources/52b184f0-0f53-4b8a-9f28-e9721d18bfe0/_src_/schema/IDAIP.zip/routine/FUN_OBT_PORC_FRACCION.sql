CREATE FUNCTION fun_obt_porc_fraccion(pEvaluacion_Fraccion_Id Number)
   RETURN Number IS
  nResultado NUMBER := 0;
  tmpSustantivo Number := 0;
  tmpAdjetivo   Number := 0;
BEGIN

 Select Round( ((sum(decode(nvl(d.respuesta,0), 0, 0,.9,1, d.respuesta)) * 100 )/ count(1)),2)  Into tmpSustantivo
       From Det_Eval_Fracciones d, Evaluaciones_Fracciones ef
         Where d.evaluacion_fraccion_id = ef.Evaluacion_Fraccion_Id
           And ef.Evaluacion_Fraccion_Id = pEvaluacion_Fraccion_Id
           And Tipo_Criterio_Id = 1
        Group BY ef.Evaluacion_Fraccion_Id;

 Select Round( ((sum(decode(nvl(d.respuesta,0), 0, 0,.9,1, d.respuesta)) * 100 )/ count(1)),2)  Into tmpAdjetivo
       From Det_Eval_Fracciones d, Evaluaciones_Fracciones ef
         Where d.evaluacion_fraccion_id = ef.Evaluacion_Fraccion_Id
           And ef.Evaluacion_Fraccion_Id = pEvaluacion_Fraccion_Id
           And Tipo_Criterio_Id = 2
        Group BY ef.Evaluacion_Fraccion_Id;

     nResultado := (tmpSustantivo * .6) +  (tmpAdjetivo * .4);

  RETURN Round(nResultado,2);

END fun_obt_porc_fraccion;
/
