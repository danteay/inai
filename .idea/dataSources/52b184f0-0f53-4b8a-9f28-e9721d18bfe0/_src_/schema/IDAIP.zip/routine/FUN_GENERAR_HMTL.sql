CREATE function fun_generar_hmtl(pEvaluacion_Id Number) return varchar2 is
  Cursor C1 Is
    select a.Descripcion,  af.Descripcion Pregunta,  af.numero, 
       af.Articulo_Id,
       afr.Respuesta Respuesta, de.respuesta Valor_Respuesta
   from evaluaciones e, Evaluaciones_Fracciones ef, Articulos_Fracciones af, 
        Articulos a, Det_Eval_Fracciones de, Art_Fracc_Respuestas afr
  where e.evaluacion_id = pEvaluacion_Id
    and e.evaluacion_id = ef.Evaluacion_Id
    And de.Evaluacion_Fraccion_Id = ef.Evaluacion_Fraccion_Id
    And afr.Art_Fracc_Respuesta_Id = de.Art_Fracc_Respuesta_Id
    And ef.Articulo_Fraccion_Id = af.Articulo_Fraccion_Id
    And af.Articulo_Id          = a.Articulo_Id
  order by af.Articulo_Id, 3;
  C2 C1%Rowtype;  
  mySql Varchar2(4000); 
begin
  
  Open C1;
  Loop
    Fetch C1 Into C2;
    Exit When C1%Notfound;
    
  End Loop;
  Close C1;
  
  Return mySql;
end fun_generar_hmtl;
/
