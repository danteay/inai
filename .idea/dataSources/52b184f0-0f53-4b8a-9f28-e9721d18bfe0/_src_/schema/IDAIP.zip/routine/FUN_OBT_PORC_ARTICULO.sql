CREATE FUNCTION fun_obt_porc_Articulo(pEvaluacion_articulo_id Number)
   RETURN Number IS
  nResultado NUMBER := 0;
  tmpSustantivo Number := 0;
  tmpAdjetivo   Number := 0;
BEGIN
  Select Avg(Nvl(prom_sustantivos,0)), Avg(Nvl(prom_adjetivos ,0)) Into tmpSustantivo, tmpAdjetivo
       From Evaluaciones_Fracciones
  Where evaluacion_articulo_id =  pEvaluacion_articulo_id;

  nResultado := (tmpSustantivo * .6) +  (tmpAdjetivo * .4);

  RETURN Round(nResultado,2);

END fun_obt_porc_Articulo;
/
