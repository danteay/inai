CREATE FUNCTION fun_obt_porc_Evaluacion(pEvaluacion_id Number)
   RETURN Number IS
  nResultado NUMBER := 0;
BEGIN

Select sum(porcentaje) Into nResultado From
(
Select Decode(a.Articulo_id, 300, .7, .3) *  nvl(fun_obt_porc_Articulo(Evaluacion_Articulo_Id ),0) Porcentaje,
       ea.Evaluacion_Articulo_Id From Evaluaciones_Articulos Ea, Articulos a
    Where ea.Articulo_Id = a.Articulo_id
      And Ea.Evaluacion_Id = pEvaluacion_id
      And Exists( select 'x' From Evaluaciones_Fracciones ef
                     Where ef.evaluacion_articulo_id = ea.Evaluacion_Articulo_Id)
                     );



  RETURN Round(nResultado,2);

END fun_obt_porc_Evaluacion;
/
