CREATE VIEW RESUMEN_SOLICITUDES_V AS select sujeto_obligado_id, sujeto,
       (Select Count(1) From Solicitudes_Informacion si, medios_solicitud ms
          Where ms.medio_solicitud_id = si.Medio_Solicitud_Id
            And si.Sujeto_Obligado_Id = so.Sujeto_Obligado_Id
            And ms.Medio_Solicitud_Id = 4
          ) Infomex,
       (Select Count(1) From Solicitudes_Informacion si, medios_solicitud ms
          Where ms.medio_solicitud_id = si.Medio_Solicitud_Id
            And si.Sujeto_Obligado_Id = so.Sujeto_Obligado_Id
            And ms.Medio_Solicitud_Id = 1
          ) Mail,
       (Select Count(1) From Solicitudes_Informacion si, medios_solicitud ms
          Where ms.medio_solicitud_id = si.Medio_Solicitud_Id
            And si.Sujeto_Obligado_Id = so.Sujeto_Obligado_Id
            And ms.Medio_Solicitud_Id = 2
          ) Telefono,
        (Select Count(1) From Solicitudes_Informacion si, medios_solicitud ms
          Where ms.medio_solicitud_id = si.Medio_Solicitud_Id
            And si.Sujeto_Obligado_Id = so.Sujeto_Obligado_Id
            And ms.Medio_Solicitud_Id = 3
          ) Convencional,
         (Select Count(1) From Solicitudes_Informacion si, medios_solicitud ms
          Where ms.medio_solicitud_id = si.Medio_Solicitud_Id
            And si.Sujeto_Obligado_Id = so.Sujeto_Obligado_Id
            And ms.Medio_Solicitud_Id = 5
          ) Medios_Inf_Otros,
          (Select Count(1) From Solicitudes_Informacion si, medios_solicitud ms
          Where ms.medio_solicitud_id = si.Medio_Solicitud_Id
            And si.Sujeto_Obligado_Id = so.Sujeto_Obligado_Id
          ) Total,

        (Select Count(1) From Solicitudes_Informacion si, Tipo_Informacion ti
          Where si.tipo_informacion_id = ti.tipo_informacion_id
            And si.Sujeto_Obligado_Id = so.Sujeto_Obligado_Id
            And ti.Tipo_Informacion_Id = 2
          ) Finaciera,
        (Select Count(1) From Solicitudes_Informacion si, Tipo_Informacion ti
          Where si.tipo_informacion_id = ti.tipo_informacion_id
            And si.Sujeto_Obligado_Id = so.Sujeto_Obligado_Id
            And ti.Tipo_Informacion_Id = 3
          ) Estadistica,
        (Select Count(1) From Solicitudes_Informacion si, Tipo_Informacion ti
          Where si.tipo_informacion_id = ti.tipo_informacion_id
            And si.Sujeto_Obligado_Id = so.Sujeto_Obligado_Id
            And ti.Tipo_Informacion_Id = 4
          ) Normativo,
         (Select Count(1) From Solicitudes_Informacion si, Tipo_Informacion ti
          Where si.tipo_informacion_id = ti.tipo_informacion_id
            And si.Sujeto_Obligado_Id = so.Sujeto_Obligado_Id
            And ti.Tipo_Informacion_Id = 5
          ) Organizacional,
         (Select Count(1) From Solicitudes_Informacion si, Tipo_Informacion ti
          Where si.tipo_informacion_id = ti.tipo_informacion_id
            And si.Sujeto_Obligado_Id = so.Sujeto_Obligado_Id
            And ti.Tipo_Informacion_Id = 6
          ) Tipo_Inf_Otros,
         (Select Count(1) From Solicitudes_Informacion si, Tipo_Informacion ti
          Where si.tipo_informacion_id = ti.tipo_informacion_id
            And si.Sujeto_Obligado_Id = so.Sujeto_Obligado_Id
          ) Total_tipo_Informacion
        from sujetos_obligados so
/
