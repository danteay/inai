CREATE VIEW TEMP_2 AS select so.sujeto_obligado_id id,so.tipo_sujeto_obligado_id tipo,so.sujeto,
       (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id

            And p.periodo_id  = 61) "A",

       (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id

            And p.periodo_id  = 81) "B",

        (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id

            And p.periodo_id  = 101) "C",

        (Select (round(sum(e.Resultado),0)||'%') From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id

            And p.periodo_id  = 121) "D",


        (Select round(sum(e.Resultado),0) From evaluaciones e, periodos p
          where e.sujeto_obligado_id=so.sujeto_obligado_id
            And p.periodo_id = e.Periodo_Id
            And e.tipo_evaluacion=1
            And e.cierre=1
            And e.sujeto_obligado_id=so.Sujeto_Obligado_Id

            And (e.periodo_id=61 or e.periodo_id=81 or e.periodo_id=101 or e.periodo_id=121)) "T",

        so.portal_internet portal
         from sujetos_obligados so
/
