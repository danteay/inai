CREATE VIEW EVALUACIONES_REPORTES_V AS select null link,numero ||'.- ' || descripcion Descripcion,
       numero,
               ef.respuesta value1 from EVALUACIONES_FRACCIONES ef, articulos_fracciones af
   where ef.articulo_fraccion_id = af.articulo_fraccion_id
   order by numero
/
