CREATE VIEW NIVEL_CUMPLIMIENTO_TS_V AS select Tipo_Sujeto, Round(avg(Promedio)) Porcentaje
  From (
select tso.descripcion Tipo_Sujeto,
       (( a1 + a2+ a3+ a4) / 4) Promedio
       from resumen_eva re, sujetos_obligados so, tipos_sujetos_obligados tso
  Where re.sujeto_obligado_id = so.sujeto_obligado_id
    And so.tipo_sujeto_obligado_id = tso.tipo_sujeto_obligado_id
    )
  Group by   Tipo_Sujeto
/
