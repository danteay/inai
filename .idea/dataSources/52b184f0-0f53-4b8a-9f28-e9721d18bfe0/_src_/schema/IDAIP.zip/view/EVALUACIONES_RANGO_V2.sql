CREATE VIEW EVALUACIONES_RANGO_V2 AS select '2' numero, '99.9' min, '101' max, 'Igual a 100' Rango,  count(1) Registros From evaluaciones,periodos
 where evaluaciones.resultado >99.9
   And evaluaciones.Tipo_Evaluacion = 1
   And evaluaciones.Cierre = 1
   and periodos.estatus=1
   and evaluaciones.periodo_id=periodos.periodo_id
  --group by resultado
union
select '4' numero, '80' min, '99.9 ' max, 'Entre 80 y 99' Rango,  count(1) Registros From evaluaciones,periodos
 where evaluaciones.resultado between 80 and 99.9
   And evaluaciones.Tipo_Evaluacion = 1
   And evaluaciones.Cierre = 1
   and periodos.estatus=1
   and evaluaciones.periodo_id=periodos.periodo_id
  --group by resultado
union
select '1' numero,'60' min, '80' max, 'Entre 60 y 79' Rango,  count(1)Registros From evaluaciones,periodos
 where evaluaciones.resultado between 60 and 79.9
  And  evaluaciones.Tipo_Evaluacion = 1
   And evaluaciones.Cierre = 1
   and periodos.estatus=1
   and evaluaciones.periodo_id=periodos.periodo_id
  --group by resultado
union
select '3' numero,'0' min, '60' max, 'Entre 0 y 59' Rango,  count(1) Registros From evaluaciones,periodos
where evaluaciones.resultado between 0 and 59.9
 And evaluaciones.Tipo_Evaluacion = 1
   And evaluaciones.Cierre = 1
   and periodos.estatus=1
   and evaluaciones.periodo_id=periodos.periodo_id
/
