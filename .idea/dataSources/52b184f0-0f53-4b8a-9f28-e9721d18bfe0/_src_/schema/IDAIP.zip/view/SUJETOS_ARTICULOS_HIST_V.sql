CREATE VIEW SUJETOS_ARTICULOS_HIST_V AS select a.articulo_clave, a.descripcion Articulo, e.sujeto_obligado_id,  af.articulo_id,
     count(1) registros from evaluaciones e, evaluaciones_fracciones ef, articulos_fracciones af, Articulos a
  where e.evaluacion_id = ef.evaluacion_id
    and af.articulo_fraccion_id = ef.articulo_fraccion_id
    And af.articulo_id          = a.articulo_id
  group by  a.articulo_clave, a.descripcion, e.sujeto_obligado_id,  af.articulo_id
/
