CREATE VIEW EVALUACIONES_RANGO_V AS select '85-100' Rango,  count(1) Registros From evaluaciones,periodos
 where evaluaciones.resultado between 85 and 100
   And evaluaciones.Tipo_Evaluacion = 1
   And evaluaciones.Cierre = 1
   and periodos.estatus=1
   and evaluaciones.periodo_id=periodos.periodo_id
  --group by resultado
union
select '60-84' Rango,  count(1)Registros From evaluaciones,periodos
 where evaluaciones.resultado between 60 and 84.9
  And  evaluaciones.Tipo_Evaluacion = 1
   And evaluaciones.Cierre = 1
   and periodos.estatus=1
   and evaluaciones.periodo_id=periodos.periodo_id
  --group by resultado
union
select '0-59' Rango,  count(1) Registros From evaluaciones,periodos
where evaluaciones.resultado between 0 and 59.9
 And evaluaciones.Tipo_Evaluacion = 1
   And evaluaciones.Cierre = 1
   and periodos.estatus=1
   and evaluaciones.periodo_id=periodos.periodo_id
  --group by resultado
/
