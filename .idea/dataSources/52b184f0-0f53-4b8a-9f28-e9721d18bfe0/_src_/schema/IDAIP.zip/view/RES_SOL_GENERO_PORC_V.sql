CREATE VIEW RES_SOL_GENERO_PORC_V AS Select Genero, Trunc((solicitudes * 100) / total ) Porcentaje
  From (
select v.*,
(Select count(1) from solicitudes_informacion) total
 from resumen_sol_genero_v v
)
/
