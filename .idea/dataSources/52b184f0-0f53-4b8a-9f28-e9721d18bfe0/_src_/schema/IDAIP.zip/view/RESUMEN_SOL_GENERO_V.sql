CREATE VIEW RESUMEN_SOL_GENERO_V AS Select decode(Genero_Solicitud,'F', 'Femenino','M','Masculino','Sin especificar') Genero,
       Count(1) Solicitudes
        from solicitudes_informacion
 Group by  decode(Genero_Solicitud,'F', 'Femenino','M','Masculino','Sin especificar')
/
