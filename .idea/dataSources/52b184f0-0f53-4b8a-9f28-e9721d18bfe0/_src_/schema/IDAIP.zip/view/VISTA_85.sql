CREATE VIEW VISTA_85 AS (select count(*) total_85 from evaluaciones where (resultado between 85 and 100) and periodo_id=61 and tipo_evaluacion=1 and cierre=1)
/
